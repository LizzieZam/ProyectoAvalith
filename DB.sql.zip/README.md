# ProyectoAvalith
React.js Tutorial with Server Side Rendering by Spring Boot and Nashorn

http://facebook.github.io/react/docs/tutorial.html

Deploy

Run Application
$ mvn spring-boot:run
Go http://localhost:8080


FRONT END WHIT REACT
This project was bootstrapped with Create React App.

Configure
The app requires only one configuration attribute, which is API server url and port. Specify it in config.js. Default is serverUrl = "http://localhost:8080", which is configured for local development.

Build and run
npm install
npm start
This will run application in develop mode with auto reload feature at http://localhost:3000.
